export class UserTemplates {
    ID: number;
    Description: string;
    TextTemplate: string;
}