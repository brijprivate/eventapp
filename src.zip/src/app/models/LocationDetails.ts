export class LocationDetails {
    ID:number;
    Description:string;
}