export class ReqResModel {
    IsReqResOk:boolean;
    ReqResReturnObj:any;
    ReqResReturnMsg:string;   

    // constructor(userName:string,password:string) {
    //     this.Username = userName;
    //     this.Password = password;
    // }
}