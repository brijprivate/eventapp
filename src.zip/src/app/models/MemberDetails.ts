export class MemberDetails {
    UserID: number;
    MemberUserID: number;
    FirstName: string;
    LastName: string;
    GenderId : number;//1-male 2-female
    Relation: number;
    EmailID: string;
    PhoneNo: string;
    
    constructor() {
        
    }
}